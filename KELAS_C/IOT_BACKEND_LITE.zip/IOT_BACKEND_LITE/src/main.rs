use actix_web::{get, post, web, App, HttpResponse, HttpServer, Responder};
use actix_cors::Cors;
use actix_multipart::Multipart;
use futures_util::StreamExt;
use serde::{Deserialize, Serialize};
use std::sync::Mutex;
use std::fs;
use std::io::Write;
use chrono::Utc;

// MongoDB v2.8
use mongodb::{bson::doc, options::ClientOptions, Client, Collection};

// ============================================================
// 1. STRUKTUR DATA SENSOR (MATCH FIRMWARE JSON)
// ============================================================
#[derive(Debug, Deserialize, Serialize, Clone, Default)]
struct Sensors {
    #[serde(default)] mq6: f32,
    #[serde(default)] mq135: f32,
    #[serde(default)] mq3: f32,
    #[serde(default)] mq7: f32,
    #[serde(default)] tgs2611: f32,
    #[serde(default)] tgs2602: f32,
    #[serde(default)] tgs2600: f32,
    #[serde(default)] tgs2620: f32,
    #[serde(default)] dht1_temp: f32,
    #[serde(default)] dht1_hum: f32,
}

#[derive(Debug, Deserialize, Serialize, Clone, Default)]
struct Status {
    #[serde(default)] inlet_pump: bool,
    #[serde(default)] inlet_valve: bool,
    #[serde(default)] outlet_pump: bool,
    #[serde(default)] outlet_valve: bool,
    #[serde(default)] inlet_time: u64,
    #[serde(default)] outlet_time: u64,
    #[serde(default)] elapsed_time: u64,
}

/// Data yang disimpan ke MongoDB
#[derive(Debug, Deserialize, Serialize, Clone)]
struct SensorData {
    #[serde(rename = "_id", skip_serializing_if = "Option::is_none")]
    id: Option<mongodb::bson::oid::ObjectId>,
    device_id: String,
    sensors: Sensors,
    status: Status,
    timestamp: i64,
    received_at: String,
}

/// Data yang diterima dari gateway (POST /data)
/// Struktur ini match dengan yang dikirim gateway.py
#[derive(Debug, Deserialize)]
struct SensorDataInput {
    device_id: String,
    #[serde(default)] sensors: Sensors,
    #[serde(default)] status: Status,
    #[serde(default)] timestamp: i64,
    #[serde(default)] received_at: String,
}

// ============================================================
// 2. STRUKTUR DATA FIRMWARE (OTA)
// ============================================================
#[derive(Debug, Serialize, Deserialize, Clone)]
struct FirmwareInfo {
    id: String,
    filename: String,
    version: String,
    size: u64,
    uploaded_at: String,
    description: String,
}

// ============================================================
// 3. STATE GLOBAL
// ============================================================
struct AppState {
    firmwares: Mutex<Vec<FirmwareInfo>>,
    sensor_collection: Collection<SensorData>,
}

// ============================================================
// 4. FUNGSI SIMPAN DATA KE MONGODB
// ============================================================
async fn simpan_data_mongo(
    state: &web::Data<AppState>,
    data: SensorData,
) -> Result<(), String> {
    match state.sensor_collection.insert_one(&data, None).await {
        Ok(_) => {
            println!(
                "💾 [MongoDB] {} | T={:.1}°C RH={:.1}% | mq6={:.0} mq135={:.0}",
                data.device_id,
                data.sensors.dht1_temp,
                data.sensors.dht1_hum,
                data.sensors.mq6,
                data.sensors.mq135,
            );
            Ok(())
        }
        Err(e) => {
            let err = format!("{:?}", e);
            println!("❌ [MongoDB] Gagal simpan: {}", err);
            Err(err)
        }
    }
}

// ============================================================
// 5. ENDPOINT HTTP: POST /data
// ============================================================
#[post("/data")]
async fn terima_data(
    data: web::Json<SensorDataInput>,
    state: web::Data<AppState>,
) -> impl Responder {
    let input = data.into_inner();

    // Konversi ke SensorData (yang disimpan)
    let sensor_data = SensorData {
        id: None,
        device_id: input.device_id.clone(),
        sensors: input.sensors,
        status: input.status,
        timestamp: input.timestamp,
        received_at: if input.received_at.is_empty() {
            Utc::now().to_rfc3339()
        } else {
            input.received_at
        },
    };

    match simpan_data_mongo(&state, sensor_data).await {
        Ok(_) => HttpResponse::Ok().json(serde_json::json!({
            "pesan": "Data berhasil disimpan",
            "device_id": input.device_id,
        })),
        Err(e) => HttpResponse::InternalServerError().json(serde_json::json!({
            "error": format!("Gagal simpan: {}", e)
        })),
    }
}

// ============================================================
// 6. ENDPOINT HTTP: GET /data
// ============================================================
#[get("/data")]
async fn ambil_data(state: web::Data<AppState>) -> impl Responder {
    use futures_util::TryStreamExt;

    // Ambil 100 data terbaru (sort by _id descending)
    use mongodb::options::FindOptions;
    let opts = FindOptions::builder()
        .sort(doc! { "_id": -1 })
        .limit(100)
        .build();

    let cursor_result = state.sensor_collection.find(doc! {}, opts).await;

    match cursor_result {
        Ok(cursor) => match cursor.try_collect::<Vec<SensorData>>().await {
            Ok(items) => HttpResponse::Ok().json(items),
            Err(e) => HttpResponse::InternalServerError().json(serde_json::json!({
                "error": format!("Gagal baca: {:?}", e)
            })),
        },
        Err(e) => HttpResponse::InternalServerError().json(serde_json::json!({
            "error": format!("Gagal query: {:?}", e)
        })),
    }
}

// ============================================================
// 7. ENDPOINT HTTP: GET /
// ============================================================
#[get("/")]
async fn halo_dunia() -> impl Responder {
    HttpResponse::Ok().body("Halo! Server Rust IoT + MongoDB berhasil jalan! ✅")
}

// ============================================================
// 8. ENDPOINT OTA: POST /ota/upload
// ============================================================
#[post("/ota/upload")]
async fn upload_firmware(
    mut payload: Multipart,
    state: web::Data<AppState>,
) -> impl Responder {
    fs::create_dir_all("firmware").ok();

    let mut filename = String::new();
    let mut file_data: Vec<u8> = Vec::new();
    let mut version = String::from("v1.0.0");
    let mut description = String::from("No description");

    while let Some(item) = payload.next().await {
        let mut field = match item {
            Ok(f) => f,
            Err(_) => continue,
        };
        let field_name = field.name().unwrap_or("").to_string();
        let mut content: Vec<u8> = Vec::new();
        while let Some(chunk) = field.next().await {
            match chunk {
                Ok(bytes) => content.extend_from_slice(&bytes),
                Err(_) => continue,
            }
        }

        match field_name.as_str() {
            "file" => {
                let cd = field.content_disposition();
                filename = cd
                    .and_then(|c| c.get_filename().map(String::from))
                    .unwrap_or_else(|| "firmware.bin".to_string());
                file_data = content;
            }
            "version" => version = String::from_utf8_lossy(&content).to_string(),
            "description" => description = String::from_utf8_lossy(&content).to_string(),
            _ => {}
        }
    }

    if file_data.is_empty() {
        return HttpResponse::BadRequest().json(serde_json::json!({
            "error": "File firmware kosong"
        }));
    }

    let id = uuid::Uuid::new_v4().to_string();
    let unique_filename = format!("{}_{}", &id[..8], filename);
    let file_path = format!("firmware/{}", unique_filename);

    let mut file = match fs::File::create(&file_path) {
        Ok(f) => f,
        Err(e) => {
            return HttpResponse::InternalServerError().json(serde_json::json!({
                "error": format!("Gagal simpan file: {}", e)
            }));
        }
    };
    if let Err(e) = file.write_all(&file_data) {
        return HttpResponse::InternalServerError().json(serde_json::json!({
            "error": format!("Gagal nulis: {}", e)
        }));
    }

    let info = FirmwareInfo {
        id: id.clone(),
        filename: unique_filename.clone(),
        version: version.clone(),
        size: file_data.len() as u64,
        uploaded_at: Utc::now().to_rfc3339(),
        description: description.clone(),
    };

    state.firmwares.lock().unwrap().push(info.clone());

    println!("📦 [OTA] Firmware baru: {} versi {}", unique_filename, version);

    HttpResponse::Ok().json(serde_json::json!({
        "pesan": "Firmware berhasil diupload!",
        "firmware": info
    }))
}

// ============================================================
// 9. ENDPOINT OTA: GET /ota/list
// ============================================================
#[get("/ota/list")]
async fn list_firmware(state: web::Data<AppState>) -> impl Responder {
    let firmwares = state.firmwares.lock().unwrap();
    HttpResponse::Ok().json(&*firmwares)
}

// ============================================================
// 10. ENDPOINT OTA: GET /ota/download/{id}
// ============================================================
#[get("/ota/download/{id}")]
async fn download_firmware(
    path: web::Path<String>,
    state: web::Data<AppState>,
) -> impl Responder {
    let id = path.into_inner();
    let firmwares = state.firmwares.lock().unwrap();

    let fw = match firmwares.iter().find(|f| f.id == id) {
        Some(f) => f.clone(),
        None => {
            return HttpResponse::NotFound().json(serde_json::json!({
                "error": "Firmware gak ditemukan"
            }));
        }
    };

    let file_path = format!("firmware/{}", fw.filename);
    match fs::read(&file_path) {
        Ok(content) => {
            println!("📤 [OTA] Download: {}", fw.filename);
            HttpResponse::Ok()
                .content_type("application/octet-stream")
                .insert_header((
                    "Content-Disposition",
                    format!("attachment; filename=\"{}\"", fw.filename),
                ))
                .body(content)
        }
        Err(e) => HttpResponse::InternalServerError().json(serde_json::json!({
            "error": format!("Gagal baca: {}", e)
        })),
    }
}

// ============================================================
// 11. ENDPOINT OTA: GET /ota/latest
// ============================================================
#[get("/ota/latest")]
async fn latest_firmware(state: web::Data<AppState>) -> impl Responder {
    let firmwares = state.firmwares.lock().unwrap();
    match firmwares.last() {
        Some(fw) => HttpResponse::Ok().json(fw),
        None => HttpResponse::NotFound().json(serde_json::json!({
            "error": "Belum ada firmware"
        })),
    }
}

// ============================================================
// 12. MAIN
// ============================================================
#[actix_web::main]
async fn main() -> std::io::Result<()> {
    fs::create_dir_all("firmware").ok();

    // Load .env
    dotenvy::dotenv().ok();

    let mongo_uri = std::env::var("MONGODB_URI")
        .expect("❌ MONGODB_URI gak ada di file .env");
    let mongo_db = std::env::var("MONGODB_DB").unwrap_or_else(|_| "iotdb".to_string());
    let mongo_col =
        std::env::var("MONGODB_COLLECTION").unwrap_or_else(|_| "sensordata".to_string());

    println!("🔌 Menghubungkan ke MongoDB Atlas...");

    let mut client_options = ClientOptions::parse(&mongo_uri)
        .await
        .expect("❌ Gagal parse connection string");
    client_options.retry_writes = Some(false);

    let client =
        Client::with_options(client_options).expect("❌ Gagal bikin MongoDB client");

    // Test ping
    client
        .database("admin")
        .run_command(doc! { "ping": 1 }, None)
        .await
        .expect("❌ Gagal ping MongoDB. Cek IP whitelist & password");

    println!("✅ MongoDB connected!");

    let sensor_collection: Collection<SensorData> =
        client.database(&mongo_db).collection(&mongo_col);

    let app_state = web::Data::new(AppState {
        firmwares: Mutex::new(Vec::new()),
        sensor_collection,
    });

    println!("\n🚀 SERVER NYALA di http://127.0.0.1:8080");
    println!("📡 [HTTP] POST /data         → simpan ke MongoDB");
    println!("📊 [HTTP] GET  /data         → 100 data terbaru");
    println!("📦 [OTA]  POST /ota/upload   → upload firmware");
    println!("📦 [OTA]  GET  /ota/list     → daftar firmware\n");

    HttpServer::new(move || {
        App::new()
            .wrap(Cors::permissive())
            .app_data(app_state.clone())
            .service(terima_data)
            .service(ambil_data)
            .service(halo_dunia)
            .service(upload_firmware)
            .service(list_firmware)
            .service(download_firmware)
            .service(latest_firmware)
    })
    .bind(("127.0.0.1", 8080))?
    .run()
    .await
}